import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import { agentReply } from './knowledge.js';

const dir = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const DATA = process.env.DATA_DIR || path.join(dir, 'data');
fs.mkdirSync(path.join(DATA, 'uploads'), { recursive: true });

// ---- Lab settings (edit here) ----
const PRICES = { adult: 500, child: 300, childAge: 12 }; // child = age under 12
const SLOTS = ['07:00-09:00', '09:00-11:00', '11:00-13:00', '16:00-18:00', '18:00-20:00'];
const TESTS = ['CBC (Complete Blood Count)', 'Blood Sugar - Fasting', 'Blood Sugar - Post Meal', 'HbA1c', 'Lipid Profile', 'Liver Function Test', 'Kidney Function Test', 'Thyroid (TSH)', 'Vitamin D', 'Vitamin B12', 'Urine Routine', 'Dengue / Malaria', 'Full Body Checkup'];
const STATUSES = ['pending', 'confirmed', 'sample_collected', 'completed', 'cancelled'];
const DOCTOR = 'Tarun Virani';

const db = new DatabaseSync(path.join(DATA, 'subham.db'));
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, role TEXT NOT NULL DEFAULT 'patient', name TEXT NOT NULL, phone TEXT UNIQUE NOT NULL, pass TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), patient_name TEXT NOT NULL, age INTEGER NOT NULL, gender TEXT, tests TEXT NOT NULL, visit_type TEXT NOT NULL, date TEXT NOT NULL, slot TEXT NOT NULL, notes TEXT, qty INTEGER NOT NULL DEFAULT 1, rate INTEGER NOT NULL, total INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS prescriptions(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), appointment_id INTEGER, file TEXT NOT NULL, orig_name TEXT, mime TEXT NOT NULL, note TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), sender TEXT NOT NULL, body TEXT NOT NULL, seen INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS medicines(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), appointment_id INTEGER, medicine TEXT NOT NULL, instructions TEXT NOT NULL, advice TEXT, doctor TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS ix_msg ON messages(user_id, id);
CREATE INDEX IF NOT EXISTS ix_app ON appointments(user_id, id);
`);

// ---- passwords / admin seed ----
const hash = pw => { const s = crypto.randomBytes(16); return s.toString('hex') + ':' + crypto.scryptSync(pw, s, 64).toString('hex'); };
const verify = (pw, st) => { const [s, h] = st.split(':'); const x = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64); return crypto.timingSafeEqual(x, Buffer.from(h, 'hex')); };
function seedAdmin(force) {
  const ex = db.prepare("SELECT id FROM users WHERE role='admin'").get();
  if (ex && !force) return;
  const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  if (ex) db.prepare('UPDATE users SET pass=? WHERE id=?').run(hash(pw), ex.id);
  else db.prepare("INSERT INTO users(role,name,phone,pass) VALUES('admin',?,?,?)").run(DOCTOR, 'tarun', hash(pw));
  console.log(`\n  ADMIN LOGIN  →  username: tarun   password: ${pw}\n  (shown once; run "npm run reset-admin" to set a new one)\n`);
}
seedAdmin(process.argv.includes('--reset-admin'));
if (process.argv.includes('--reset-admin')) process.exit(0);

// ---- helpers ----
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(a => a[0]).map(([k, ...v]) => [k, v.join('=')]));
const userOf = req => { const t = cookies(req).sid; return t ? db.prepare('SELECT u.id,u.role,u.name,u.phone FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?').get(t, Date.now()) : null; };
const need = (req, role) => { const u = userOf(req); if (!u) throw new HttpError(401, 'Please log in'); if (role && u.role !== role) throw new HttpError(403, 'Not allowed'); return u; };
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
const str = (v, min, max, label) => { const s = String(v ?? '').trim(); if (s.length < min || s.length > max) throw new HttpError(400, `${label} is invalid`); return s; };
const int = (v, min, max, label) => { const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) throw new HttpError(400, `${label} is invalid`); return n; };
async function body(req, limit = 20_000) {
  if (!/^application\/json/.test(req.headers['content-type'] || '')) throw new HttpError(415, 'JSON required');
  let size = 0; const chunks = [];
  for await (const c of req) { size += c.length; if (size > limit) throw new HttpError(413, 'Request too large'); chunks.push(c); }
  try { return JSON.parse(Buffer.concat(chunks).toString() || '{}'); } catch { throw new HttpError(400, 'Bad JSON'); }
}
const rows = (sql, ...p) => db.prepare(sql).all(...p);
const row = (sql, ...p) => db.prepare(sql).get(...p);
const run = (sql, ...p) => Number(db.prepare(sql).run(...p).lastInsertRowid);

// ---- realtime (Server-Sent Events) ----
const userStreams = new Map(); const adminStreams = new Set();
const emit = (set, ev, d) => { for (const r of set) r.write(`event: ${ev}\ndata: ${JSON.stringify(d)}\n\n`); };
const toUser = (id, ev, d) => userStreams.has(id) && emit(userStreams.get(id), ev, d);
const toAdmins = (ev, d) => emit(adminStreams, ev, d);
setInterval(() => { for (const s of [...adminStreams, ...[...userStreams.values()].flatMap(x => [...x])]) s.write(': ping\n\n'); }, 25000).unref();

// ---- login throttle ----
const fails = new Map();
const throttled = ip => (fails.get(ip) || []).filter(t => Date.now() - t < 600_000).length >= 10;
const noteFail = ip => fails.set(ip, [...(fails.get(ip) || []).filter(t => Date.now() - t < 600_000), Date.now()]);

function startSession(res, uid) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
  db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(token, uid, Date.now() + 7 * 864e5);
  res.setHeader('Set-Cookie', `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${7 * 86400}${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`);
}

const E = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function billHtml(a, u) {
  return `<!doctype html><meta charset="utf-8"><title>Bill SL-${String(a.id).padStart(5, '0')}</title><link rel="stylesheet" href="/style.css"><body class="billpage"><div class="bill">
<h1>✚ Subham Laboratory</h1><p class="muted">Pathology &amp; Diagnostics · Consulting doctor: Dr. ${E(DOCTOR)}</p><hr>
<p><b>Bill No:</b> SL-${String(a.id).padStart(5, '0')} &nbsp; <b>Booked:</b> ${E(a.created_at)} UTC</p>
<p><b>Patient:</b> ${E(a.patient_name)} (${a.age} yrs${a.gender ? ', ' + E(a.gender) : ''})<br><b>Appointment:</b> ${E(a.date)} · ${E(a.slot)} · ${a.visit_type === 'home' ? 'Home collection' : 'Lab visit'}<br><b>Tests:</b> ${E(a.tests)}</p>
<table><tr><th>Item</th><th>Rate</th><th>Qty</th><th>Amount</th></tr><tr><td>${a.age < PRICES.childAge ? 'Child' : 'Adult'} report bill</td><td>₹${a.rate}</td><td>${a.qty}</td><td>₹${a.total}</td></tr><tr><th colspan="3">Total payable</th><th>₹${a.total}</th></tr></table>
<p class="muted">Status: ${E(a.status)} · Payment is made at the lab.</p><button id="p" class="btn">Print</button><script src="/print.js"></script></div>`;
}

// ---- API ----
async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  const ip = req.socket.remoteAddress;
  let g;

  if (m === 'GET' && p === '/api/config') return send(res, 200, { prices: PRICES, slots: SLOTS, tests: TESTS, statuses: STATUSES, doctor: DOCTOR, today: today() });
  if (m === 'GET' && p === '/api/me') return send(res, 200, { user: userOf(req) });

  if (m === 'POST' && p === '/api/register') {
    const b = await body(req);
    const name = str(b.name, 2, 60, 'Name'), phone = String(b.phone || '');
    if (!/^[6-9]\d{9}$/.test(phone)) throw new HttpError(400, 'Enter a valid 10-digit mobile number');
    const pw = str(b.password, 6, 100, 'Password (min 6 characters)');
    if (row('SELECT 1 FROM users WHERE phone=?', phone)) throw new HttpError(409, 'This mobile number is already registered');
    const id = run("INSERT INTO users(role,name,phone,pass) VALUES('patient',?,?,?)", name, phone, hash(pw));
    startSession(res, id); return send(res, 201, { user: { id, role: 'patient', name, phone } });
  }
  if (m === 'POST' && p === '/api/login') {
    if (throttled(ip)) throw new HttpError(429, 'Too many attempts. Try again in 10 minutes.');
    const b = await body(req);
    const u = row('SELECT * FROM users WHERE phone=?', String(b.phone || '').trim().toLowerCase());
    if (!u || !verify(String(b.password || ''), u.pass)) { noteFail(ip); throw new HttpError(401, 'Wrong mobile number or password'); }
    startSession(res, u.id); return send(res, 200, { user: { id: u.id, role: u.role, name: u.name, phone: u.phone } });
  }
  if (m === 'POST' && p === '/api/logout') {
    const t = cookies(req).sid; if (t) db.prepare('DELETE FROM sessions WHERE token=?').run(t);
    res.setHeader('Set-Cookie', 'sid=; HttpOnly; Path=/; Max-Age=0'); return send(res, 200, { ok: true });
  }

  if (m === 'GET' && p === '/api/stream') {
    const u = need(req);
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' }); res.write('retry: 3000\n\n');
    const set = u.role === 'admin' ? adminStreams : (userStreams.get(u.id) || userStreams.set(u.id, new Set()).get(u.id));
    set.add(res); req.on('close', () => { set.delete(res); if (!set.size && u.role !== 'admin') userStreams.delete(u.id); });
    return;
  }

  // appointments
  if (m === 'POST' && p === '/api/appointments') {
    const u = need(req, 'patient'), b = await body(req);
    const age = int(b.age, 0, 120, 'Age'), qty = int(b.qty ?? 1, 1, 5, 'Number of reports');
    const date = str(b.date, 10, 10, 'Date'); if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date < today() || isNaN(Date.parse(date))) throw new HttpError(400, 'Choose today or a future date');
    if (!SLOTS.includes(b.slot)) throw new HttpError(400, 'Choose a time slot');
    if (!['lab', 'home'].includes(b.visit_type)) throw new HttpError(400, 'Choose lab visit or home collection');
    const gender = ['Male', 'Female', 'Other'].includes(b.gender) ? b.gender : null;
    const rate = age < PRICES.childAge ? PRICES.child : PRICES.adult;
    const a = { patient_name: str(b.patient_name, 2, 60, 'Patient name'), tests: str(b.tests, 2, 400, 'Tests (choose at least one)'), notes: b.notes ? str(b.notes, 0, 400, 'Notes') : null };
    const id = run('INSERT INTO appointments(user_id,patient_name,age,gender,tests,visit_type,date,slot,notes,qty,rate,total) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', u.id, a.patient_name, age, gender, a.tests, b.visit_type, date, b.slot, a.notes, qty, rate, rate * qty);
    const ap = row('SELECT * FROM appointments WHERE id=?', id);
    toAdmins('appointment', { ...ap, phone: u.phone }); return send(res, 201, { appointment: ap });
  }
  if (m === 'GET' && p === '/api/appointments') {
    const u = need(req);
    return send(res, 200, { appointments: u.role === 'admin' ? rows('SELECT a.*,u.phone FROM appointments a JOIN users u ON u.id=a.user_id ORDER BY a.date DESC,a.id DESC LIMIT 500') : rows('SELECT * FROM appointments WHERE user_id=? ORDER BY id DESC', u.id) });
  }
  if (m === 'PATCH' && (g = p.match(/^\/api\/admin\/appointments\/(\d+)$/))) {
    need(req, 'admin'); const b = await body(req); if (!STATUSES.includes(b.status)) throw new HttpError(400, 'Bad status');
    const a = row('SELECT * FROM appointments WHERE id=?', g[1]); if (!a) throw new HttpError(404, 'Not found');
    db.prepare('UPDATE appointments SET status=? WHERE id=?').run(b.status, a.id);
    toUser(a.user_id, 'appointment', { id: a.id, status: b.status }); return send(res, 200, { ok: true });
  }
  if (m === 'GET' && (g = p.match(/^\/bill\/(\d+)$/))) {
    const u = need(req); const a = row('SELECT * FROM appointments WHERE id=?', g[1]);
    if (!a || (u.role !== 'admin' && a.user_id !== u.id)) throw new HttpError(404, 'Not found');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(billHtml(a, u));
  }

  // prescriptions
  if (m === 'POST' && p === '/api/prescriptions') {
    const u = need(req, 'patient'), b = await body(req, 8_000_000);
    const mm = /^data:(image\/jpeg|image\/png|image\/webp|application\/pdf);base64,([A-Za-z0-9+/=]+)$/.exec(b.file || ''); if (!mm) throw new HttpError(400, 'Upload a JPG, PNG, WEBP or PDF file');
    const buf = Buffer.from(mm[2], 'base64'); if (buf.length > 5_000_000) throw new HttpError(413, 'File must be under 5 MB');
    const magic = { 'image/jpeg': [0xff, 0xd8], 'image/png': [0x89, 0x50], 'image/webp': [0x52, 0x49], 'application/pdf': [0x25, 0x50] }[mm[1]];
    if (buf[0] !== magic[0] || buf[1] !== magic[1]) throw new HttpError(400, 'File content does not match its type');
    const file = crypto.randomBytes(16).toString('hex') + { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'application/pdf': '.pdf' }[mm[1]];
    fs.writeFileSync(path.join(DATA, 'uploads', file), buf);
    let apId = null; if (b.appointment_id) { const a = row('SELECT id FROM appointments WHERE id=? AND user_id=?', Number(b.appointment_id), u.id); apId = a ? a.id : null; }
    const id = run('INSERT INTO prescriptions(user_id,appointment_id,file,orig_name,mime,note) VALUES(?,?,?,?,?,?)', u.id, apId, file, String(b.name || '').slice(0, 80), mm[1], b.note ? String(b.note).slice(0, 300) : null);
    toAdmins('prescription', { id, user_id: u.id, name: u.name }); return send(res, 201, { id });
  }
  if (m === 'GET' && p === '/api/prescriptions') { const u = need(req); return send(res, 200, { prescriptions: rows('SELECT id,appointment_id,orig_name,mime,note,created_at FROM prescriptions WHERE user_id=? ORDER BY id DESC', u.id) }); }
  if (m === 'GET' && (g = p.match(/^\/api\/prescriptions\/(\d+)\/file$/))) {
    const u = need(req); const r = row('SELECT * FROM prescriptions WHERE id=?', g[1]);
    if (!r || (u.role !== 'admin' && r.user_id !== u.id)) throw new HttpError(404, 'Not found');
    res.writeHead(200, { 'Content-Type': r.mime, 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'", 'Cache-Control': 'private, no-store' });
    return fs.createReadStream(path.join(DATA, 'uploads', path.basename(r.file))).pipe(res);
  }

  // chat
  if (m === 'GET' && p === '/api/messages') { const u = need(req, 'patient'); return send(res, 200, { messages: rows('SELECT id,sender,body,created_at FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 200', u.id).reverse() }); }
  if (m === 'POST' && p === '/api/messages') {
    const u = need(req, 'patient'), b = await body(req); const text = str(b.body, 1, 1000, 'Message');
    const id = run("INSERT INTO messages(user_id,sender,body) VALUES(?,'patient',?)", u.id, text);
    const msg = { id, user_id: u.id, sender: 'patient', body: text, created_at: row('SELECT created_at FROM messages WHERE id=?', id).created_at, name: u.name };
    toAdmins('message', msg); toUser(u.id, 'message', msg); return send(res, 201, { message: msg });
  }
  if (m === 'POST' && p === '/api/admin/messages') {
    need(req, 'admin'); const b = await body(req); const uid = int(b.user_id, 1, 1e9, 'Patient'), text = str(b.body, 1, 1000, 'Message');
    if (!row("SELECT 1 FROM users WHERE id=? AND role='patient'", uid)) throw new HttpError(404, 'Patient not found');
    const id = run("INSERT INTO messages(user_id,sender,body,seen) VALUES(?,'admin',?,1)", uid, text);
    const msg = { id, user_id: uid, sender: 'admin', body: text, created_at: row('SELECT created_at FROM messages WHERE id=?', id).created_at };
    toUser(uid, 'message', msg); toAdmins('message', msg); return send(res, 201, { message: msg });
  }

  // medicines (doctor → agent → patient)
  if (m === 'GET' && p === '/api/medicines') { const u = need(req, 'patient'); return send(res, 200, { medicines: rows('SELECT * FROM medicines WHERE user_id=? ORDER BY id DESC', u.id) }); }
  if (m === 'POST' && p === '/api/admin/medicines') {
    need(req, 'admin'); const b = await body(req); const uid = int(b.user_id, 1, 1e9, 'Patient');
    if (!row("SELECT 1 FROM users WHERE id=? AND role='patient'", uid)) throw new HttpError(404, 'Patient not found');
    const med = str(b.medicine, 2, 120, 'Medicine'), ins = str(b.instructions, 2, 300, 'Dose / instructions'), adv = b.advice ? str(b.advice, 0, 500, 'Advice') : null;
    const id = run('INSERT INTO medicines(user_id,appointment_id,medicine,instructions,advice,doctor) VALUES(?,?,?,?,?,?)', uid, b.appointment_id ? Number(b.appointment_id) : null, med, ins, adv, DOCTOR);
    const text = `🤖 Assistant: Dr. ${DOCTOR} has suggested for you → ${med} — ${ins}${adv ? '. Advice: ' + adv : ''}. Follow only what the doctor advised; ask him if unsure.`;
    const mid = run("INSERT INTO messages(user_id,sender,body) VALUES(?,'agent',?)", uid, text);
    const msg = { id: mid, user_id: uid, sender: 'agent', body: text, created_at: row('SELECT created_at FROM messages WHERE id=?', mid).created_at };
    toUser(uid, 'message', msg); toUser(uid, 'medicine', { id }); toAdmins('message', msg); return send(res, 201, { id });
  }

  // AI agent
  if (m === 'POST' && p === '/api/agent') {
    const u = userOf(req); const b = await body(req); const text = str(b.text, 1, 600, 'Message');
    const medicines = u?.role === 'patient' ? rows('SELECT * FROM medicines WHERE user_id=? ORDER BY id DESC LIMIT 20', u.id) : [];
    return send(res, 200, { reply: await agentReply(text, { user: u, medicines, prices: PRICES }) });
  }

  // admin data
  if (m === 'GET' && p === '/api/admin/stats') {
    need(req, 'admin');
    return send(res, 200, {
      today: row('SELECT COUNT(*) n FROM appointments WHERE date=?', today()).n, pending: row("SELECT COUNT(*) n FROM appointments WHERE status='pending'").n,
      patients: row("SELECT COUNT(*) n FROM users WHERE role='patient'").n, unread: row("SELECT COUNT(*) n FROM messages WHERE sender='patient' AND seen=0").n,
      revenue: row("SELECT COALESCE(SUM(total),0) n FROM appointments WHERE status='completed'").n,
    });
  }
  if (m === 'GET' && p === '/api/admin/patients') {
    need(req, 'admin');
    return send(res, 200, { patients: rows(`SELECT u.id,u.name,u.phone,
      (SELECT COUNT(*) FROM messages m WHERE m.user_id=u.id AND m.sender='patient' AND m.seen=0) unread,
      (SELECT MAX(created_at) FROM messages m WHERE m.user_id=u.id) last_msg,
      (SELECT COUNT(*) FROM appointments a WHERE a.user_id=u.id) appts
      FROM users u WHERE u.role='patient' ORDER BY COALESCE(last_msg,u.created_at) DESC LIMIT 500`) });
  }
  if (m === 'GET' && p === '/api/admin/thread') {
    need(req, 'admin'); const uid = int(url.searchParams.get('user_id'), 1, 1e9, 'Patient');
    db.prepare("UPDATE messages SET seen=1 WHERE user_id=? AND sender='patient'").run(uid);
    return send(res, 200, {
      messages: rows('SELECT id,sender,body,created_at FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 200', uid).reverse(),
      prescriptions: rows('SELECT id,appointment_id,orig_name,mime,note,created_at FROM prescriptions WHERE user_id=? ORDER BY id DESC', uid),
      medicines: rows('SELECT * FROM medicines WHERE user_id=? ORDER BY id DESC', uid),
      appointments: rows('SELECT id,patient_name,tests,date,slot,status FROM appointments WHERE user_id=? ORDER BY id DESC', uid),
    });
  }
  throw new HttpError(404, 'Not found');
}

// ---- static + server ----
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const SEC = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin', 'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; frame-ancestors 'none'" };

http.createServer(async (req, res) => {
  for (const [k, v] of Object.entries(SEC)) res.setHeader(k, v);
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/bill/')) return await api(req, res, url);
    if (req.method !== 'GET') throw new HttpError(405, 'Method not allowed');
    let f = url.pathname === '/' ? '/index.html' : url.pathname === '/admin' ? '/admin.html' : url.pathname;
    const full = path.normalize(path.join(dir, 'public', f));
    if (!full.startsWith(path.join(dir, 'public') + path.sep) || !fs.existsSync(full) || !fs.statSync(full).isFile()) throw new HttpError(404, 'Not found');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(full).pipe(res);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e instanceof HttpError) return send(res, e.code, { error: e.message });
    console.error(e); send(res, 500, { error: 'Something went wrong' });
  }
}).listen(PORT, () => console.log(`Subham Laboratory running → http://localhost:${PORT}   (admin: /admin)`));

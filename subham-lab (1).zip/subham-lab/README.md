# Subham Laboratory — web app

Online appointment booking, prescription upload, live doctor chat, AI assistant and an admin panel for **Dr. Tarun Virani**.
Zero dependencies: Node.js 22.5+ and its built-in SQLite database (`data/subham.db`).

## Run
```bash
npm start            # http://localhost:3000   (admin panel: /admin)
```
On first start the console prints the admin login (username `tarun`, random password). To choose your own,
start once with `ADMIN_PASSWORD=yourPassword npm start` on a fresh database, or run `npm run reset-admin` to generate a new one.

## Settings (top of server.js)
Prices (₹500 adult / ₹300 child, child = under 12), time slots, test list. Optional env vars: `PORT`, `DATA_DIR`,
`ANTHROPIC_API_KEY` (lets the assistant answer free-form questions through Claude, always restricted to the doctor's approved medicines),
`NODE_ENV=production` (secure cookies — use HTTPS).

## SQL tables
users, sessions, appointments, prescriptions, messages, medicines.

## How the medicine feature works
The doctor types a medicine and dose in the admin panel → it is saved in the `medicines` table → the AI assistant posts it to the
patient's chat and shows it in "My appointments". The assistant never invents medicines or doses.

## Before going live
Put it behind HTTPS (Caddy, nginx or a host such as Render/Railway with a persistent disk for `data/`), back up `data/`,
and have it reviewed for patient-data privacy rules before storing real medical records.

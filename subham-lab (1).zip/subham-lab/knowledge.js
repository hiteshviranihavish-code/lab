// Subham Laboratory AI assistant. Deterministic tools first; optional Claude for free-form questions.
const ANALYTES = [
  { a: ['hemoglobin', 'haemoglobin', 'hb'], n: 'Hemoglobin', u: 'g/dL', lo: 12, hi: 17, note: 'Normal ranges differ for men and women.' },
  { a: ['wbc', 'tlc', 'white blood cells', 'white cell count'], n: 'WBC count', u: '/µL', lo: 4000, hi: 11000 },
  { a: ['platelets', 'platelet', 'plt'], n: 'Platelets', u: '/µL', lo: 150000, hi: 450000 },
  { a: ['fasting blood sugar', 'fasting sugar', 'fasting glucose', 'fbs', 'blood sugar', 'sugar', 'glucose'], n: 'Fasting glucose', u: 'mg/dL', lo: 70, hi: 99, note: 'Assumes a fasting sample.' },
  { a: ['hba1c', 'a1c'], n: 'HbA1c', u: '%', lo: 4, hi: 5.6 },
  { a: ['total cholesterol', 'cholesterol'], n: 'Total cholesterol', u: 'mg/dL', lo: 0, hi: 199 },
  { a: ['ldl cholesterol', 'ldl'], n: 'LDL cholesterol', u: 'mg/dL', lo: 0, hi: 99 },
  { a: ['hdl cholesterol', 'hdl'], n: 'HDL cholesterol', u: 'mg/dL', lo: 40, hi: 1000 },
  { a: ['triglycerides', 'triglyceride', 'tg'], n: 'Triglycerides', u: 'mg/dL', lo: 0, hi: 149 },
  { a: ['tsh'], n: 'TSH', u: 'mIU/L', lo: 0.4, hi: 4.0 },
  { a: ['creatinine'], n: 'Creatinine', u: 'mg/dL', lo: 0.6, hi: 1.3 },
  { a: ['vitamin d', 'vit d'], n: 'Vitamin D', u: 'ng/mL', lo: 30, hi: 100 },
  { a: ['vitamin b12', 'b12'], n: 'Vitamin B12', u: 'pg/mL', lo: 200, hi: 900 },
  { a: ['sgpt', 'alt'], n: 'SGPT (ALT)', u: 'U/L', lo: 7, hi: 56 },
];

export function explainValues(text) {
  let work = text.toLowerCase();
  const found = [];
  const aliases = ANALYTES.flatMap(x => x.a.map(al => [al, x])).sort((p, q) => q[0].length - p[0].length);
  for (const [al, x] of aliases) {
    const re = new RegExp(`\\b${al.replace(/ /g, '\\s+')}\\b[^\\d\\n]{0,25}?(\\d+(?:\\.\\d+)?)`, 'i');
    const m = re.exec(work);
    if (!m || found.some(f => f.x === x)) continue;
    work = work.slice(0, m.index) + ' '.repeat(m[0].length) + work.slice(m.index + m[0].length);
    found.push({ x, v: Number(m[1]) });
  }
  if (!found.length) return null;
  const lines = found.map(({ x, v }) => {
    const st = v < x.lo ? 'below' : v > x.hi ? 'above' : 'within';
    const range = x.lo === 0 ? `up to ${x.hi}` : x.hi >= 1000 && x.n.startsWith('HDL') ? `${x.lo} or more` : `${x.lo}–${x.hi}`;
    return `• ${x.n}: ${v} ${x.u} — ${st} the typical adult range (${range}).${x.note ? ' ' + x.note : ''}`;
  });
  return `Here is a plain-language comparison:\n${lines.join('\n')}\n\nThese are general reference ranges; the ranges printed on your lab report take priority. A value outside the range is not a diagnosis — please discuss it with Dr. Tarun Virani.`;
}

const SYMPTOMS = [
  [['fever', 'chills', 'body ache', 'body pain'], 'CBC, Dengue/Malaria tests, Typhoid (Widal), Urine routine'],
  [['tired', 'fatigue', 'weakness', 'low energy'], 'CBC, Vitamin D, Vitamin B12, Thyroid (TSH), Blood sugar'],
  [['thirst', 'frequent urination', 'diabetes', 'sugar'], 'Fasting + post-meal blood sugar, HbA1c, Urine routine'],
  [['hair fall', 'hair loss', 'weight gain', 'cold intolerance'], 'Thyroid (TSH), Vitamin D, Vitamin B12, CBC'],
  [['burning urine', 'urine infection', 'uti'], 'Urine routine & culture, Kidney function test'],
  [['jaundice', 'yellow eyes', 'liver'], 'Liver function test, CBC'],
  [['cholesterol', 'heart check', 'bp', 'blood pressure'], 'Lipid profile, Blood sugar, Kidney function test'],
  [['health checkup', 'full body', 'routine check'], 'Full body checkup: CBC, sugar, lipid, liver, kidney, thyroid, Vitamin D & B12'],
];
const PREP = [
  [['sugar', 'glucose', 'fasting'], 'Blood sugar (fasting): 8–10 hours of fasting; plain water is fine. Do not skip prescribed medicines unless the doctor says so.'],
  [['lipid', 'cholesterol'], 'Lipid profile: 9–12 hours of fasting, plain water only; avoid alcohol and heavy fatty meals the day before.'],
  [['hba1c', 'a1c'], 'HbA1c: no fasting needed.'],
  [['thyroid', 'tsh'], 'Thyroid (TSH): fasting is not required; morning samples are preferred. Mention any thyroid medicine you take.'],
  [['cbc', 'blood count'], 'CBC: no fasting needed.'],
  [['urine'], 'Urine test: collect a mid-stream first-morning sample in a clean container provided by the lab.'],
  [['liver', 'kidney', 'lft', 'kft'], 'Liver/Kidney tests: 8–10 hours of fasting is usually advised.'],
  [['vitamin'], 'Vitamin D / B12: fasting is usually not required; the lab will confirm at collection.'],
];
const EMERGENCY = /chest pain|can'?t breathe|breathless|unconscious|seizure|severe bleeding|stroke|suicid|overdose|poison/i;
const has = (t, ws) => ws.some(w => new RegExp(`\\b${w}s?\\b`).test(t));

export async function agentReply(text, ctx) {
  const t = text.toLowerCase();
  if (EMERGENCY.test(text)) return 'This may be an emergency. Please call 112 or go to the nearest hospital right now. Do not wait for an online reply.';

  const vals = explainValues(text);
  if (vals) return vals;

  if (has(t, ['medicine', 'tablet', 'dawai', 'dawa', 'prescription', 'dose', 'capsule', 'syrup'])) {
    if (!ctx.user) return 'Please log in so I can show the medicines your doctor has suggested for you.';
    if (!ctx.medicines.length) return 'Dr. Tarun Virani has not added any medicine suggestions for you yet. Send him a message in "Doctor chat" and he will respond. I never suggest medicines on my own.';
    const list = ctx.medicines.map(m => `• ${m.medicine} — ${m.instructions}${m.advice ? `\n  Advice: ${m.advice}` : ''}\n  (Dr. ${m.doctor}, ${m.created_at.slice(0, 10)})`).join('\n');
    return `These are the suggestions from your doctor:\n${list}\n\nI only repeat what the doctor wrote. Do not change doses or add medicines without asking him. If you have side effects or feel worse, contact a doctor immediately.`;
  }
  if (has(t, ['price', 'rate', 'cost', 'charge', 'fee', 'bill', 'rupees']))
    return `Report bill: ₹${ctx.prices.adult} for adults and ₹${ctx.prices.child} for children under ${ctx.prices.childAge}. You can print your bill from "My appointments".`;
  const prep = PREP.filter(([k]) => has(t, k)).map(x => x[1]);
  if (prep.length && has(t, ['fast', 'prepare', 'preparation', 'before', 'empty', 'food', 'eat', 'how'])) return `${prep.join('\n')}\n\nThis is general guidance; our staff will confirm before collection.`;
  const sym = SYMPTOMS.filter(([k]) => has(t, k));
  if (sym.length) return `Tests that doctors commonly order for this:\n${sym.map(s => '• ' + s[1]).join('\n')}\n\nThis is not a diagnosis. You can book these under "Book appointment" or ask Dr. Tarun Virani which ones you need.`;
  if (has(t, ['book', 'appointment', 'slot', 'home collection', 'sample']))
    return 'Go to "Book appointment", choose your tests, a date and a time slot (lab visit or home collection). You will get a bill number instantly.';

  if (process.env.ANTHROPIC_API_KEY) {
    try {
      const meds = ctx.medicines.map(m => `${m.medicine}: ${m.instructions}`).join('; ') || 'none';
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST', signal: AbortSignal.timeout(20000),
        headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 400,
          system: `You are the assistant of Subham Laboratory, a pathology lab (doctor: Tarun Virani). Reply briefly in the user's language. Adult report bill ₹${ctx.prices.adult}, child ₹${ctx.prices.child}. Doctor-approved medicines for this patient: ${meds}. Rules: never diagnose; never recommend any medicine or dose that is not in the doctor-approved list; for symptoms suggest seeing the doctor; for emergencies say call 112.`,
          messages: [{ role: 'user', content: text }],
        }),
      });
      const d = await r.json();
      const out = d?.content?.find(c => c.type === 'text')?.text;
      if (out) return out;
    } catch { /* fall through */ }
  }
  return 'I can help with: 💊 your doctor-approved medicines, 🧪 which tests suit your symptoms, 📊 explaining report values (e.g. "hemoglobin 10.2, sugar 130"), 🍽 fasting instructions, 💰 prices and 📅 booking. What would you like?';
}

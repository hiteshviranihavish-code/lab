const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const when = s => new Date(s.replace(' ', 'T') + 'Z').toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
async function api(url, method = 'GET', body) {
  const r = await fetch(url, { method, headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}
const A = { tab: 'appts', sel: null, cfg: null, patients: [], thread: null };
const toast = t => { const e = document.createElement('div'); e.className = 'toast'; e.textContent = t; document.body.append(e); setTimeout(() => e.remove(), 5000); };
const beep = () => { try { const c = new AudioContext(), o = c.createOscillator(); o.connect(c.destination); o.frequency.value = 880; o.start(); o.stop(c.currentTime + .15); } catch { } };
const bubbles = l => l.map(m => `<div class="b ${m.sender === 'admin' ? 'me' : m.sender === 'agent' ? 'agent' : ''}"><small>${m.sender === 'admin' ? 'You' : m.sender === 'agent' ? 'AI assistant' : 'Patient'} · ${when(m.created_at)}</small>${esc(m.body)}</div>`).join('');

function login() {
  $('#nav').innerHTML = '';
  $('#view').innerHTML = `<form class="card" id="f"><h2>Admin login</h2><label>Username<input name="phone" required autocomplete="username"></label><label>Password<input name="password" type="password" required autocomplete="current-password"></label><button class="btn">Login</button><div id="msg"></div></form>`;
  $('#f').onsubmit = async e => { e.preventDefault(); try { const r = await api('/api/login', 'POST', Object.fromEntries(new FormData(e.target))); if (r.user.role !== 'admin') { await api('/api/logout', 'POST', {}); throw new Error('This account is not an admin'); } start(r.user); } catch (x) { $('#msg').innerHTML = `<p class="err">${esc(x.message)}</p>`; } };
}
async function start(me) {
  A.cfg = await api('/api/config');
  $('#nav').innerHTML = `<span class="muted">Dr. ${esc(me.name)}</span><button id="out">Logout</button>`;
  $('#out').onclick = async () => { await api('/api/logout', 'POST', {}); location.reload(); };
  const es = new EventSource('/api/stream');
  es.addEventListener('appointment', e => { const a = JSON.parse(e.data); beep(); toast(`New appointment: ${a.patient_name} · ${a.date} ${a.slot}`); refresh(); });
  es.addEventListener('prescription', e => { toast(`Prescription from ${JSON.parse(e.data).name}`); if (A.sel) openThread(A.sel, true); });
  es.addEventListener('message', e => {
    const m = JSON.parse(e.data); if (m.sender === 'patient') beep();
    if (A.sel === m.user_id && A.tab === 'chat') { A.thread.messages.push(m); drawMsgs(); if (m.sender === 'patient') api('/api/admin/thread?user_id=' + m.user_id); }
    else if (m.sender === 'patient') toast(`Message from ${m.name || 'patient'}`);
    refresh();
  });
  await refresh();
}
async function refresh() {
  const [s, p] = await Promise.all([api('/api/admin/stats'), api('/api/admin/patients')]); A.patients = p.patients;
  $('#view').innerHTML = `<div class="cards"><div class="card"><b class="big">${s.today}</b><br>Appointments today</div><div class="card"><b class="big">${s.pending}</b><br>Pending</div><div class="card"><b class="big">${s.unread}</b><br>Unread messages</div><div class="card"><b class="big">₹${s.revenue}</b><br>Completed revenue · ${s.patients} patients</div></div>
<div class="tabs"><button data-t="appts" class="${A.tab === 'appts' ? 'on' : ''}">Appointments</button><button data-t="chat" class="${A.tab === 'chat' ? 'on' : ''}">Patients &amp; live chat</button></div><div id="pane"></div>`;
  document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { A.tab = b.dataset.t; refresh(); });
  A.tab === 'appts' ? await drawAppts() : drawChat();
}
async function drawAppts() {
  const { appointments } = await api('/api/appointments');
  $('#pane').innerHTML = `<div class="scroll"><table><tr><th>Bill</th><th>Patient</th><th>Tests</th><th>When</th><th>Total</th><th>Status</th></tr>${appointments.map(a => `<tr><td><a href="/bill/${a.id}" target="_blank">SL-${String(a.id).padStart(5, '0')}</a></td><td>${esc(a.patient_name)}<br><span class="muted">${a.age} yrs · ${esc(a.phone)}</span></td><td>${esc(a.tests)}${a.notes ? `<br><span class="muted">${esc(a.notes)}</span>` : ''}</td><td>${esc(a.date)}<br>${esc(a.slot)}<br><span class="muted">${a.visit_type === 'home' ? 'Home collection' : 'Lab visit'}</span></td><td>₹${a.total}</td><td><select data-id="${a.id}">${A.cfg.statuses.map(s => `<option ${s === a.status ? 'selected' : ''} value="${s}">${s.replace('_', ' ')}</option>`).join('')}</select></td></tr>`).join('') || '<tr><td colspan="6" class="muted">No appointments yet.</td></tr>'}</table></div>`;
  document.querySelectorAll('select[data-id]').forEach(s => s.onchange = async () => { try { await api('/api/admin/appointments/' + s.dataset.id, 'PATCH', { status: s.value }); toast('Status updated · patient notified'); refresh(); } catch (x) { toast(x.message); } });
}
function drawChat() {
  $('#pane').innerHTML = `<div class="admin"><div class="plist">${A.patients.map(p => `<button class="pi ${A.sel === p.id ? 'on' : ''}" data-id="${p.id}"><span>${esc(p.name)}<br><small class="muted">${esc(p.phone)}</small></span>${p.unread ? `<span class="dot">${p.unread}</span>` : ''}</button>`).join('') || '<p class="muted pad">No patients yet.</p>'}</div><div id="th"><p class="muted">Select a patient.</p></div></div>`;
  document.querySelectorAll('.pi').forEach(b => b.onclick = () => openThread(Number(b.dataset.id)));
  if (A.sel) openThread(A.sel, true);
}
function drawMsgs() { const m = $('#m'); if (!m) return; m.innerHTML = bubbles(A.thread.messages); m.scrollTop = m.scrollHeight; }
async function openThread(id, keep) {
  A.sel = id; const p = A.patients.find(x => x.id === id); if (!p) return;
  A.thread = await api('/api/admin/thread?user_id=' + id); const t = A.thread;
  document.querySelectorAll('.pi').forEach(b => b.classList.toggle('on', Number(b.dataset.id) === id));
  $('#th').innerHTML = `<h3>${esc(p.name)} <span class="muted">${esc(p.phone)}</span></h3><div class="chat"><div class="msgs" id="m"></div><form class="send" id="f"><input name="b" maxlength="1000" placeholder="Reply to patient…" autocomplete="off" required><button class="btn">Send</button></form></div>
<h3>📄 Prescriptions</h3><div>${t.prescriptions.map(r => `<p><a target="_blank" href="/api/prescriptions/${r.id}/file">${esc(r.orig_name || 'Prescription')}</a> <span class="muted">${when(r.created_at)}${r.note ? ' · ' + esc(r.note) : ''}</span></p>`).join('') || '<p class="muted">None uploaded.</p>'}</div>
<h3>💊 Suggest medicine (the AI assistant will deliver it to the patient)</h3><form class="card" id="mf"><label>Medicine<input name="medicine" required maxlength="120"></label><label>Dose / how to take<input name="instructions" required maxlength="300" placeholder="e.g. 1 tablet after food, twice daily for 5 days"></label><label>Advice (optional)<input name="advice" maxlength="500"></label><button class="btn">Send suggestion</button></form>
<h3>Given so far</h3>${t.medicines.map(m => `<p>💊 <b>${esc(m.medicine)}</b> — ${esc(m.instructions)} <span class="muted">${when(m.created_at)}</span></p>`).join('') || '<p class="muted">None yet.</p>'}`;
  drawMsgs();
  $('#f').onsubmit = async e => { e.preventDefault(); const i = e.target.b, v = i.value; i.value = ''; try { await api('/api/admin/messages', 'POST', { user_id: id, body: v }); } catch (x) { toast(x.message); i.value = v; } };
  $('#mf').onsubmit = async e => { e.preventDefault(); try { await api('/api/admin/medicines', 'POST', { user_id: id, ...Object.fromEntries(new FormData(e.target)) }); toast('Suggestion sent to patient'); openThread(id, true); } catch (x) { toast(x.message); } };
  api('/api/admin/patients').then(r => { A.patients = r.patients; });
}
(async () => { try { const { user } = await api('/api/me'); user?.role === 'admin' ? start(user) : login(); } catch { login(); } })();

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const when = s => new Date(s.replace(' ', 'T') + 'Z').toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
async function api(url, method = 'GET', body) {
  const r = await fetch(url, { method, headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}
const S = { me: null, cfg: null, es: null, unread: 0, view: 'home', onMsg: null };
const toast = t => { const e = document.createElement('div'); e.className = 'toast'; e.textContent = t; document.body.append(e); setTimeout(() => e.remove(), 5000); };
const bubbles = list => list.map(m => `<div class="b ${m.sender === 'patient' ? 'me' : m.sender}"><small>${m.sender === 'admin' ? 'Dr. Tarun Virani' : m.sender === 'agent' ? 'AI assistant' : 'You'} · ${when(m.created_at)}</small>${esc(m.body)}</div>`).join('');
const scrollEnd = el => { el.scrollTop = el.scrollHeight; };

function nav() {
  const L = [['home', 'Home'], ['book', 'Book'], ['appts', 'My appointments'], ['rx', 'Prescriptions'], ['chat', 'Doctor chat'], ['ai', '✨ AI assistant']];
  $('#nav').innerHTML = L.map(([h, t]) => `<a href="#${h}" class="${S.view === h ? 'on' : ''}">${t}${h === 'chat' && S.unread ? `<span class="dot">${S.unread}</span>` : ''}</a>`).join('') +
    (S.me ? `<button id="out">Logout (${esc(S.me.name.split(' ')[0])})</button>` : '<a href="#login">Login</a>');
  const o = $('#out'); if (o) o.onclick = async () => { await api('/api/logout', 'POST', {}); S.me = null; S.es?.close(); location.hash = '#home'; boot(); };
}
function connect() {
  if (S.es || !S.me) return;
  S.es = new EventSource('/api/stream');
  S.es.addEventListener('message', e => { const m = JSON.parse(e.data); if (m.sender === 'patient') return S.onMsg?.(m); if (S.onMsg) S.onMsg(m); else { S.unread++; nav(); toast(m.sender === 'agent' ? 'New suggestion from the doctor' : 'New message from Dr. Tarun Virani'); } });
  S.es.addEventListener('appointment', e => { const a = JSON.parse(e.data); toast(`Appointment #${a.id} is now ${a.status.replace('_', ' ')}`); if (S.view === 'appts') views.appts(); });
}

const views = {
  home() {
    const p = S.cfg.prices;
    $('#view').innerHTML = `<section class="hero"><h1>Accurate reports.<br><span>Caring doctors.</span></h1><p>Book your tests, upload your prescription and chat live with Dr. Tarun Virani — all from your phone.</p><a class="btn" href="#book">Book appointment</a> <a class="btn ghost" href="#ai">Try the AI assistant</a></section>
<section class="cards"><div class="card price"><h3>Adult report bill</h3><div class="big">₹${p.adult}</div><span class="muted">per report</span></div><div class="card price"><h3>Children's report bill</h3><div class="big">₹${p.child}</div><span class="muted">patients under ${p.childAge} years</span></div></section>
<section class="grid"><div class="card"><h3>📅 Online booking</h3>Pick tests, date and a slot. Lab visit or home collection. Instant printable bill.</div><div class="card"><h3>📄 Upload prescription</h3>Send your doctor's prescription as a photo or PDF, securely.</div><div class="card"><h3>💬 Live doctor chat</h3>Talk to Dr. Tarun Virani online and get his advice.</div><div class="card"><h3>✨ AI assistant</h3>Explains report values, suggests tests for symptoms, shows fasting rules and your doctor-approved medicines.</div></section>`;
  },
  async book() {
    const c = S.cfg;
    $('#view').innerHTML = `<h2>Book an appointment</h2><form class="card" id="f"><label>Patient name<input name="patient_name" required minlength="2" maxlength="60" value="${esc(S.me.name)}"></label>
<div class="two"><label>Age (years)<input name="age" type="number" min="0" max="120" required></label><label>Gender<select name="gender"><option>Male</option><option>Female</option><option>Other</option></select></label></div>
<div><b>Tests</b><div class="checks">${c.tests.map(t => `<label><input type="checkbox" name="t" value="${esc(t)}">${esc(t)}</label>`).join('')}</div></div>
<label>Other test / doctor's advice (optional)<input name="other" maxlength="200"></label>
<div class="two"><label>Visit type<select name="visit_type"><option value="lab">Visit the lab</option><option value="home">Home sample collection</option></select></label><label>Number of reports<input name="qty" type="number" min="1" max="5" value="1"></label></div>
<div class="two"><label>Date<input name="date" type="date" min="${c.today}" value="${c.today}" required></label><label>Time slot<select name="slot">${c.slots.map(s => `<option>${s}</option>`).join('')}</select></label></div>
<label>Notes<textarea name="notes" maxlength="400"></textarea></label><div><b id="tot"></b></div><button class="btn">Confirm booking</button><div id="msg"></div></form>`;
    const f = $('#f'), calc = () => { const age = Number(f.age.value), q = Number(f.qty.value) || 1; $('#tot').textContent = f.age.value === '' ? 'Enter age to see the bill' : `Bill: ₹${(age < c.prices.childAge ? c.prices.child : c.prices.adult) * q} (${age < c.prices.childAge ? 'child' : 'adult'} rate × ${q})`; };
    f.oninput = calc; calc();
    f.onsubmit = async e => {
      e.preventDefault(); const d = Object.fromEntries(new FormData(f));
      const tests = [...f.querySelectorAll('[name=t]:checked')].map(x => x.value); if (d.other) tests.push(d.other);
      try { const r = await api('/api/appointments', 'POST', { ...d, tests: tests.join(', ') }); $('#msg').innerHTML = `<p class="ok">Booked! Bill SL-${String(r.appointment.id).padStart(5, '0')} · ₹${r.appointment.total}. <a href="/bill/${r.appointment.id}" target="_blank">Open bill</a> · <a href="#appts">View details</a></p>`; }
      catch (x) { $('#msg').innerHTML = `<p class="err">${esc(x.message)}</p>`; }
    };
  },
  async appts() {
    const [{ appointments }, { medicines }] = await Promise.all([api('/api/appointments'), api('/api/medicines')]);
    $('#view').innerHTML = `<h2>My appointments</h2>${appointments.length ? '' : '<p class="muted">No appointments yet. <a href="#book">Book one</a>.</p>'}<div class="grid">${appointments.map(a => `<div class="card"><span class="badge ${a.status}">${a.status.replace('_', ' ')}</span><h3>SL-${String(a.id).padStart(5, '0')} · ${esc(a.patient_name)}</h3>
<div>${esc(a.tests)}</div><div class="muted">${esc(a.date)} · ${esc(a.slot)} · ${a.visit_type === 'home' ? 'Home collection' : 'Lab visit'}</div><p><b>₹${a.total}</b> <span class="muted">(${a.qty} × ₹${a.rate})</span></p><a class="btn sm" href="/bill/${a.id}" target="_blank">View / print bill</a></div>`).join('')}</div>
${medicines.length ? `<h2>Doctor's suggestions</h2><div class="grid">${medicines.map(m => `<div class="card"><h3>💊 ${esc(m.medicine)}</h3>${esc(m.instructions)}${m.advice ? `<p class="muted">${esc(m.advice)}</p>` : ''}<small class="muted">Dr. ${esc(m.doctor)} · ${when(m.created_at)}</small></div>`).join('')}</div>` : ''}`;
  },
  async rx() {
    const [{ prescriptions }, { appointments }] = await Promise.all([api('/api/prescriptions'), api('/api/appointments')]);
    $('#view').innerHTML = `<h2>Upload prescription</h2><form class="card" id="f"><label>Photo or PDF (max 5 MB)<input type="file" name="file" accept="image/jpeg,image/png,image/webp,application/pdf" required></label>
<label>For appointment (optional)<select name="appointment_id"><option value="">—</option>${appointments.map(a => `<option value="${a.id}">SL-${String(a.id).padStart(5, '0')} · ${esc(a.date)}</option>`).join('')}</select></label><label>Note for the doctor<input name="note" maxlength="300"></label><button class="btn">Upload</button><div id="msg"></div></form>
<h2>My prescriptions</h2><div class="grid">${prescriptions.map(r => `<div class="card">📄 ${esc(r.orig_name || 'Prescription')}<div class="muted">${when(r.created_at)}</div>${r.note ? `<div>${esc(r.note)}</div>` : ''}<a class="btn sm" target="_blank" href="/api/prescriptions/${r.id}/file">Open</a></div>`).join('') || '<p class="muted">Nothing uploaded yet.</p>'}</div>`;
    $('#f').onsubmit = async e => {
      e.preventDefault(); const f = e.target, file = f.file.files[0];
      if (file.size > 5_000_000) return $('#msg').innerHTML = '<p class="err">File must be under 5 MB</p>';
      const dataUrl = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(file); });
      try { await api('/api/prescriptions', 'POST', { file: dataUrl, name: file.name, note: f.note.value, appointment_id: f.appointment_id.value }); toast('Prescription sent to the doctor'); views.rx(); }
      catch (x) { $('#msg').innerHTML = `<p class="err">${esc(x.message)}</p>`; }
    };
  },
  async chat() {
    S.unread = 0; nav();
    const { messages } = await api('/api/messages');
    $('#view').innerHTML = `<h2>Chat with Dr. Tarun Virani</h2><p class="muted">Messages arrive live. The doctor may take a few minutes to reply.</p><div class="chat"><div class="msgs" id="m">${bubbles(messages) || '<p class="muted">Say hello 👋</p>'}</div><form class="send" id="f"><input name="b" maxlength="1000" placeholder="Type your message…" autocomplete="off" required><button class="btn">Send</button></form></div>`;
    const m = $('#m'); scrollEnd(m); const seen = new Set(messages.map(x => x.id));
    S.onMsg = x => { if (seen.has(x.id)) return; seen.add(x.id); m.insertAdjacentHTML('beforeend', bubbles([x])); scrollEnd(m); };
    $('#f').onsubmit = async e => { e.preventDefault(); const i = e.target.b; const t = i.value; i.value = ''; try { const r = await api('/api/messages', 'POST', { body: t }); S.onMsg(r.message); } catch (x) { toast(x.message); i.value = t; } };
  },
  ai() {
    const chips = ['What medicines did the doctor suggest?', 'I feel tired and weak, which tests?', 'Explain: hemoglobin 10.2, sugar 135, cholesterol 230', 'Do I need to fast for lipid profile?', 'What are your prices?'];
    $('#view').innerHTML = `<h2>✨ AI assistant</h2><p class="muted">Shows your doctor-approved medicines, suggests tests, explains values and fasting rules. It does not diagnose and never prescribes on its own.</p>
<div class="chat"><div class="msgs" id="m"><div class="b agent"><small>AI assistant</small>Hi${S.me ? ' ' + esc(S.me.name.split(' ')[0]) : ''}! Ask me anything about tests, reports, fasting or your doctor's suggestions.</div></div><form class="send" id="f"><input name="t" maxlength="600" placeholder="Ask the assistant…" autocomplete="off" required><button class="btn">Ask</button></form></div><div class="chips">${chips.map(c => `<button class="chip">${esc(c)}</button>`).join('')}</div>`;
    const m = $('#m'), ask = async t => {
      m.insertAdjacentHTML('beforeend', `<div class="b me">${esc(t)}</div>`); scrollEnd(m);
      try { const r = await api('/api/agent', 'POST', { text: t }); m.insertAdjacentHTML('beforeend', `<div class="b agent"><small>AI assistant</small>${esc(r.reply)}</div>`); } catch (x) { m.insertAdjacentHTML('beforeend', `<div class="b agent">${esc(x.message)}</div>`); } scrollEnd(m);
    };
    $('#f').onsubmit = e => { e.preventDefault(); const i = e.target.t; const t = i.value; i.value = ''; ask(t); };
    document.querySelectorAll('.chip').forEach(c => c.onclick = () => ask(c.textContent));
  },
  login() {
    let reg = false;
    const draw = () => {
      $('#view').innerHTML = `<form class="card" id="f"><h2>${reg ? 'Create account' : 'Login'}</h2>${reg ? '<label>Full name<input name="name" required minlength="2" maxlength="60"></label>' : ''}<label>Mobile number<input name="phone" inputmode="numeric" required maxlength="10" placeholder="10-digit number"></label><label>Password<input name="password" type="password" required minlength="6" autocomplete="${reg ? 'new' : 'current'}-password"></label><button class="btn">${reg ? 'Register' : 'Login'}</button><div id="msg"></div><a href="#login" id="sw">${reg ? 'Already registered? Login' : 'New patient? Create account'}</a></form>`;
      $('#sw').onclick = e => { e.preventDefault(); reg = !reg; draw(); };
      $('#f').onsubmit = async e => {
        e.preventDefault(); try { const r = await api(reg ? '/api/register' : '/api/login', 'POST', Object.fromEntries(new FormData(e.target))); if (r.user.role === 'admin') { location.href = '/admin'; return; } S.me = r.user; connect(); const t = '#' + (S.next || 'home'); S.next = null; if (location.hash === t) route(); else location.hash = t; }
        catch (x) { $('#msg').innerHTML = `<p class="err">${esc(x.message)}</p>`; }
      };
    };
    draw();
  },
};
async function route() {
  S.onMsg = null;
  const v = location.hash.slice(1) || 'home'; S.view = views[v] ? v : 'home';
  if (['book', 'appts', 'rx', 'chat'].includes(S.view) && !S.me) { S.next = S.view; S.view = 'login'; }
  nav(); try { await views[S.view](); } catch (e) { $('#view').innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
async function boot() { [S.cfg, { user: S.me }] = await Promise.all([api('/api/config'), api('/api/me')]); if (S.me?.role === 'admin') S.me = null; connect(); route(); }
window.addEventListener('hashchange', route); boot();

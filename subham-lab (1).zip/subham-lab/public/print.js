document.getElementById('p').addEventListener('click', () => print());
